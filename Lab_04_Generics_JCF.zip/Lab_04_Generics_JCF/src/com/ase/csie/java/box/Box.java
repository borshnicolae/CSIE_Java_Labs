package com.ase.csie.java.box;

public class Box {
	
	public Object o;

	public Box(Object o) {
		super();
		this.o = o;
	}

	public Object getO() {
		return o;
	}

	public void setO(Object o) {
		this.o = o;
	}
	
	

}
