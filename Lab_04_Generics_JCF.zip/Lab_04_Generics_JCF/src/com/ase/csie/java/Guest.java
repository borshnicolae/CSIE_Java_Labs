package com.ase.csie.java;

public class Guest {
	private String name;

	public Guest(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
