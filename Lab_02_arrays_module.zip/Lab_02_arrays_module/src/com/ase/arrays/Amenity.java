package com.ase.arrays;


public enum Amenity {
WIFI,
MINI_BAR,
TV
}
