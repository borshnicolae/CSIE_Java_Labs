/**
 * 
 */
/**
 * 
 */
module HotelRoom {
	exports com.ase.arrays;
}