/**
 * 
 */
/**
 * 
 */
module Lab_02_arrays_use_module {
	requires HotelRoom;
}