package com.ase.csie.java;

public enum Amenity {
WIFI,
MINI_BAR,
TV
}
