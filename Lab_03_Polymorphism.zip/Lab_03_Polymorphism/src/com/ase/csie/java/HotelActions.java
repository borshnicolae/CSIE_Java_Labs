package com.ase.csie.java;

public interface HotelActions {
	/*private*/ public /*static final*/ int MAX_BOOKINGS = 10; // by default public static final
	
	public void bookRoom();
	public float calcPrice();
}
