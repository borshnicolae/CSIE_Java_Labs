package eu.ase.java.poly.areaFig;

public interface Area {
	public static final float PI = 3.14f;
	
	float calcArea();
}
