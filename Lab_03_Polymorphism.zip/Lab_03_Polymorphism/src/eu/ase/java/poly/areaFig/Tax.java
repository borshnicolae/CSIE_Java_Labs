package eu.ase.java.poly.areaFig;

public interface Tax extends Area{
	public float TAX = 2.5f;
	
	float calcTax();
}
